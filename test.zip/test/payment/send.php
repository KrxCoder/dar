<?php

$TOKEN = ""; // Your Bot Token

$ID = -1001837706889; // Your User ID

$ChUsername = "hack666m"; // Your Channel User Name

?>